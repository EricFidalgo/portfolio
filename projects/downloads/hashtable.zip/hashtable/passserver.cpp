/* This file deals with the pair username and password which is similar in a way of the hashtable.hpp. Uses libsodium for modern password hashing. */
#include "passserver.h"
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <sodium.h> 
#include <cstring>

namespace cop4530 {

std::string PassServer::encrypt(const std::string &str)
{
    // Start the buffer for the hash
    unsigned char hash[crypto_pwhash_STRBYTES];
    
    // Generate a random salt using libsodium and the Argon2id algorithm
    if (crypto_pwhash_str(
        (char*)hash,
        str.c_str(),
        str.length(),
        crypto_pwhash_OPSLIMIT_INTERACTIVE,
        crypto_pwhash_MEMLIMIT_INTERACTIVE) != 0) {
        throw std::runtime_error("Password hashing failed");
    }
    
    // Convert to string and return
    return std::string((char*)hash);
}

PassServer::PassServer(size_t size)
{
    // Initialize libsodium
    if (sodium_init() < 0) {
        throw std::runtime_error("Libsodium initialization failed");
    }
    users = cop4530::HashTable<std::string, std::string>(size);
}

PassServer::~PassServer()
{
    users.clear(); 
}

bool PassServer::load(const char *filename)
{
    size_t counts = 0; 
    std::ifstream file(filename);
    if (file.is_open() == false) 
    {
        std::cout << "Error: File could not be opened." << std::endl;
        return false;
    }

    std::string username, password; 
    while (file >> username >> password)
    {
        std::cout << "User Number: " << counts << std::endl;
        counts++; 
        std::string passwrd_encrypt = encrypt(password); 
        users.insert(std::make_pair(username, passwrd_encrypt));
    }
    file.close(); 

    return true; 
}

bool PassServer::addUser(std::pair<std::string, std::string> & kv)
{
    if (users.contains(kv.first))
    {
        return false; // User already exists
    }

    std::string passwrd_encrypt = encrypt(kv.second);
    users.insert(std::make_pair(kv.first, passwrd_encrypt));
    return true;
}

bool PassServer::addUser(std::pair<std::string, std::string> && kv)
{
    if (users.contains(kv.first))
    {
        return false; // User already exists
    }

    std::string passwrd_encrypt = encrypt(std::move(kv.second));
    users.insert(std::make_pair(std::move(kv.first), passwrd_encrypt));
    return true; 
}

bool PassServer::removeUser(const std::string & k)
{
    users.remove(k);
    return true; 
}

bool PassServer::changePassword(const std::pair<std::string, std::string> &p, const std::string & newpassword)
{
    if (users.contains(p.first) == false)
    {
        return false;
    }

    std::string encrypted_current = encrypt(p.second);
    std::pair<std::string, std::string> current_pair = {p.first, encrypted_current};

    if (users.match(current_pair) == false)
    {
        return false; 
    }

    std::string encrypted_new = encrypt(newpassword);
    if (encrypted_new == encrypted_current)
    {
        return false; 
    }

    std::pair<std::string, std::string> new_pair = {p.first, encrypted_new};
    users.insert(new_pair); 
    return true;
}

bool PassServer::find(const std::string & user) const
{
    return users.contains(user);
}

void PassServer::dump()
{
    users.dump();
}

size_t PassServer::size() const
{
    return users.size();
}

bool PassServer::write_to_file(const char *filename) const
{
    users.write_to_file(filename);
    return true; 
}

size_t PassServer::table_size() const 
{
    return users.table_size(); 
}
}