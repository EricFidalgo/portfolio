Before running this program, make sure that you have installed the necessary dependencies:

1. Libsodium 

- Ubuntu/Debian:
  sudo apt install libsodium-dev
- MacOS (Homebrew):
  brew install libsodium
- Windows (vcpkg):
  vcpkg install libsodium

2. Argon2

- Ubuntu/Debian:
  sudo apt install libargon2-dev
- MacOS (Homebrew):
  brew install argon2
- Windows (vcpkg):
  vcpkg install argon2