/* This file deals with the actual hastable, the key and the value pair. All functions have been created by me besides the prime_below() and setPrimes() which were given by my professor.*/
namespace cop4530 {

template <typename K, typename V>
void HashTable<K, V>::makeEmpty()
{
  for (auto& chain : table)
  {
    chain.clear(); 
  }
}

template <typename K, typename V>
void HashTable<K, V>::rehash()
{
  unsigned long newSize = prime_below(std::min(static_cast<unsigned int>(2 * current_table_size), max_prime)); // * 2 to find the next prime number, static cast to an unsigned int for both variables

  std::vector<std::list<std::pair<K, V>>> newTemp(newSize);

  current_table_size = newSize; 

  for (size_t i=0; i < table.size(); i++)
  {
    if (table[i].empty() == true)
    {
      continue;
    }

    auto iterator = table[i].begin(); 
    for (; iterator != table[i].end(); iterator++)
    {
      size_t tempKey = myhash(iterator -> first) % newSize; 
      newTemp[tempKey].emplace_back(iterator-> first, iterator-> second); 
    }
  }

  table = std::move(newTemp); 
}

template <typename K, typename V>
size_t HashTable<K, V>::myhash(const K &k) const 
{
  return (std::hash<K>{} (k) % table.size()); 
}


// returns largest prime number <= n or zero if input is too large
// This is likely to be more efficient than prime_above(), because
// it only needs a vector of size n
template <typename K, typename V>
unsigned long HashTable<K, V>::prime_below (unsigned long n)
{
  if (n > max_prime)
    {
      std::cerr << "** input too large for prime_below()\n";
      return 0;
    }
  if (n == max_prime)
    {
      return max_prime;
    }
  if (n <= 1)
    {
		std::cerr << "** input too small \n";
      return 0;
    }
  // now: 2 <= n < max_prime
  std::vector <unsigned long> v (n+1);
  setPrimes(v);
  while (n > 2)
    {
      if (v[n] == 1)
	return n;
      --n;
    }
  return 2;
}

//Sets all prime number indexes to 1. Called by method prime_below(n) 
template <typename K, typename V>
void HashTable<K, V>::setPrimes(std::vector<unsigned long>& vprimes)
{
  int i = 0;
  int j = 0;

  vprimes[0] = 0;
  vprimes[1] = 0;
  int n = vprimes.capacity();

  for (i = 2; i < n; ++i)
    vprimes[i] = 1;

  for( i = 2; i*i < n; ++i)
    {
      if (vprimes[i] == 1)
        for(j = i + i ; j < n; j += i)
          vprimes[j] = 0;
    }
}


template <typename K, typename V>
HashTable<K, V>::HashTable(size_t size)
{
    size_t primeSize = prime_below(size);
    table.resize(primeSize);

    current_table_size = primeSize; 
}


template <typename K, typename V>
HashTable<K, V>::~HashTable()
{
  makeEmpty(); 
}

template <typename K, typename V>
bool HashTable<K, V>::contains(const K &k) const 
{
  size_t hashValue = myhash(k); 
  auto& cell = table[hashValue]; 
  auto iterator = cell.begin();

  for (; iterator != cell.end(); iterator++)
  {
    if (iterator-> first == k) 
    {
      return true; 
    }
  }

  return false; 
}

template <typename K, typename V> 
bool HashTable<K, V>::match(const std::pair<K,V> &k) const
{
  size_t hashValue = myhash(k.first); 
  auto& cell = table[hashValue]; 
  auto iterator = cell.begin();


  for (; iterator != cell.end(); iterator++)
  {
    if (iterator-> first == k.first && iterator-> second == k.second)
    {
      return true; 
    }
  }

  return false; 

}

template <typename K, typename V>
bool HashTable<K, V>::insert(const std::pair<K,V> &kv)
{
  if (size() > table.size())
    {
        rehash(); 
    }
    
  size_t hashValue = myhash(kv.first); 
  auto& cell = table[hashValue]; 
  auto iterator = cell.begin(); 
  for (; iterator != cell.end(); iterator++)
  {
    if (iterator-> first == kv.first && iterator-> second == kv.second)
    {
      return false; 
    }

    if (iterator -> first == kv.first)
    {
      iterator -> second = kv.second; 
      return true; 
    }
  }

    cell.emplace_back(kv.first, kv.second); 
    return true; 
}


template <typename K, typename V>
bool HashTable<K, V>::insert(std::pair<K, V> && kv)
{

  if (size() > table.size())
    {
        rehash(); 
    }
  size_t hashValue = myhash(kv.first); 
  auto& cell = table[hashValue]; 
  auto iterator = cell.begin(); 
  for (; iterator != cell.end(); iterator++)
  {
    if (iterator-> first == kv.first && iterator-> second == kv.second)
    {
      return false; 
    }

    if (iterator -> first == kv.first)
    {
      std::cout << "Warning: Duplicate key '" << kv.first << "', value updated" << std::endl;
      iterator -> second = kv.second; 
      return true; 
    }
  }
    cell.emplace_back(kv.first, kv.second); 
    return true; 
}

template <typename K, typename V>
bool HashTable<K, V>::remove(const K &k)
{
  size_t hashValue = myhash(k); 
  auto& cell = table[hashValue]; 
  auto iterator = cell.begin(); 

  for (; iterator != cell.end(); iterator++)
  {
    if (iterator -> first == k)
    {
      cell.erase(iterator); 
      return true; 
    }
  }

  return false; 
}

template <typename K, typename V>
void HashTable<K,V>::clear()
{
  makeEmpty(); 
}

template <typename K, typename V>
bool HashTable<K,V>::load(const char *filename)
{
  std::ifstream file(filename);
  if (file.is_open() == false) 
  {
    std::cout << "Error: File could not be opened." << std::endl;
    return false;
  }

  std::string key, value; 
  while (file >> key >> value)
  {
    insert({key, value});
  }
  file.close(); 

  return true; 
}


template <typename K, typename V>
void HashTable<K,V>::dump() const
{
  for (size_t i = 0; i < table.size(); i++)
  {
    std::cout << "v[" << i << "]: ";
    if (table[i].empty())
    {
      std::cout << std::endl;
      continue; 
    }

    auto iterator = table[i].begin(); 
    for (; iterator != table[i].end(); iterator++)
    {
      std::cout << iterator->first << ":" << iterator->second << " " << std::endl;
    }
  }
}

template <typename K, typename V>
size_t HashTable<K,V>::size() const
{
  unsigned long sum = 0;  
  for (size_t i = 0; i < table.size(); i++)
  {
    sum += table[i].size(); 
  }

  return sum; 
}

template <typename K, typename V>
bool HashTable<K, V>::write_to_file(const char *filename) const
{
  std::ofstream file(filename);

  if (!file.is_open()) 
  {
    std::cout << "Error: File could not be opened for writing." << std::endl;
    return false;
  }

  for (size_t i =0; i < table.size(); i++)
  {
    auto iterator = table[i].begin();
    for (; iterator != table[i].end(); iterator++)
    {
      file << iterator->first << " " << iterator->second << std::endl;
    }
  }

  file.close();
  return true; 
}

template <typename K, typename V>
size_t HashTable<K, V>::table_size() const
{
  return table.size(); 
}

}
