#include <iostream>
#include <string>
#include <cctype>
#include <vector>
#include "stack.h"
using namespace std;
using namespace cop4530;

string toPostFix(const string& infix);
int precedence(const string &op);
vector<string> create_blocks(const string& str);
double postFixMath(const string& postfix); 
double lookForDigit(const string& postfix, const int& index); 

bool no_variables = true; 

int main()
{
  string input; 
  
  cout << "type \"exit\" or an empty space to quit the program.\ninfix: ";
  while (getline(cin,input))
  {
    if (input == "exit" || input.empty())
    {
      break; 
    }

    for (size_t i=0; i < input.size(); i++)
    {
      if ((input[i] == '+' || input[i] == '-' || input[i] == '*' || input[i] == '/') && (input[i-1] == '+' || input[i-1] == '-' || input[i-1] == '*' || input[i-1] == '/'))
      {
        input = "ERROR: An operator does not have the corresponding operands"; 
        break; 
      }
    }
    if (input == "ERROR: An operator does not have the corresponding operands")
    {
      cout << input << endl; 
    }
    // The previous if statements are used to see: if input[i] has two operators one after the other then there is an error. 
    else // if no errors we go here
    {
      string postfix = toPostFix(input); 
      cout << "postfix: " << postfix;

      if (no_variables == true) { // this is done if there are is only numbers so we can do the math
        double final_val = postFixMath(postfix);
        cout << " = " << final_val << endl;
      }
    
  }
  cout << "\ninfix: ";
  }
  return 0;
}

string toPostFix(const string& infix)
{
  vector<string> the_block = create_blocks(infix); // first we separate in between every whitespace into blocks (tokenize)
  if (the_block[0] == "err")
  {
    return "An operator does not have the corresponding operands"; 
  }
  Stack<string> operators;
  string postfix = ""; 

  for (string block: the_block)
  {
    if (block == "(")
    {
      operators.push(block); 
    }

    else if (block == ")")
    {
      while (!operators.empty() && operators.top() != "(")
      // all the way till operators are emptied && the top operator does not equal "("
			{
				postfix += operators.top() + " ";
				operators.pop();
			}
      
      if (!operators.empty() && operators.top() == "(")
      // if operator == "(" then we just pop the parentheses
      {
        operators.pop();
      }

      else 
      {
        return "ERROR: There is a mismatch in parentheses!"; 
      }
    
    }

    else if (block == "+" || block == "-" || block == "*" || block == "/")
    {
        while (!operators.empty() && precedence(operators.top()) >= precedence(block))
        // operator goes all the way till emptied && can only print the operators if the current block has a higher precedence than the one under it
      {
        postfix += operators.top() + " "; 
        operators.pop(); 
      }
      operators.push(block); 
    }

    else if (block == " ")
    {
      continue; 
    }
    else // all the numbers and variables
    {
      postfix += block + " "; 
    }
  }


  while (!operators.empty()) // this is for the final amount of operators to add all of them to the postfix
      {
        postfix += operators.top() + " "; 
        operators.pop(); 
      }

      return postfix; 
}

double postFixMath(const string& postfix)
{
  Stack<double> numbers;
  string current_num = "";
  
  for (size_t i = 0; i < postfix.size(); i++)
  {
      if (isdigit(postfix[i]))
      {
          // Build the complete number
          while (i < postfix.size() && (isdigit(postfix[i]) || postfix[i] == '.'))
          {
              current_num += postfix[i];
              i++;
          }
          numbers.push(stod(current_num));
          current_num = "";
      }
      else if (postfix[i] == '+' || postfix[i] == '-' || postfix[i] == '*' || postfix[i] == '/')
      {   
          double second = numbers.top(); numbers.pop();
          double first = numbers.top(); numbers.pop();
          
          switch (postfix[i])
          {
              case '+':
                  numbers.push(first + second);
                  break;
              case '-':
                  numbers.push(first - second);
                  break;
              case '*':
                  numbers.push(first * second);
                  break;
              case '/':
                  if (second == 0) {
                      cout << "Error: Division by zero" << endl;
                      return 0;
                  }
                  numbers.push(first / second);
                  break;
          }
      }
  }
  
  if (numbers.size() != 1)
  {
      cout << "Error: Invalid expression" << endl;
      return 0;
  }
  return numbers.top();
}

vector<string> create_blocks(const string& str)
{
  no_variables = true; 
  vector<string> to_blocks;
  string current_block = ""; 

  for (size_t i=0; i <= str.size(); i++)
  {
    if(isspace(str[i]) || i == str.size())
    // if str[i] equals an empty space or if it is at the end then insert the whole block and a white space
    {
      to_blocks.insert(to_blocks.end(), {current_block, " "}); // adds all of the characters + a whitespace
      current_block = ""; 
    }

    else 
    {
      if (isalpha(str[i])) // looks to see if there are any alphabetic letters for the postfix calculation
      {
        no_variables = false; 
      }
      current_block += str[i]; // this will add on each character until a white space
    }
  }

  return to_blocks; 
}

int precedence(const string &op) // will deal with the while loop. function will be called twice and there will be a comparison between two return values
{
    if (op == "+" || op == "-") 
    {
      return 1; 
    } 
    else if (op == "*" || op == "/") 
    {
      return 2; 
    }

    return 0; 
}