#ifndef STACK_HPP
#define STACK_HPP

namespace cop4530 {

template <typename T>
Stack<T>::Stack() 
{ 

}

template <typename T>
Stack<T>::~Stack() 
{ 

}

// copy constructors 
template <typename T>
Stack<T>::Stack(const Stack& a)
{
  data = a.data;
}

template <typename T>
Stack<T>::Stack(Stack&& a) : data(std::move(a.data))
{
  a.data.clear();
}

// copy assignment operators
template<typename T>
Stack<T>& Stack<T>::operator=(const Stack<T>& a)
{
  data = a.data;
  return *this; 
}

template<typename T>
Stack<T>& Stack<T>::operator=(Stack<T>&& a)
{
  data = a.data; 
  a.data.clear(); 
  return *this; 
}


// member functions
template<typename T>
bool Stack<T>::empty() const
{
  //returns true if the Stack contains no elements, and false otherwise.  
  return data.empty(); 
}

template<typename T>
void Stack<T>::clear()
{
  data.clear(); 
}

template<typename T>
void Stack<T>::push(const T& x)
{
  data.push_back(x); 
}

template<typename T>
void Stack<T>::push(T&& x)
{
  data.push_back(std::move(x)); 
}

template<typename T>
void Stack<T>::pop()
{
  data.pop_back();  
}

template<typename T>
T& Stack<T>::top()
{
  return data.back(); 
}

template<typename T>
const T& Stack<T>::top() const
{
  return data.back(); 
}

template<typename T>
int Stack<T>::size() const
{
  return data.size(); 
}

template <typename T>
void Stack<T>::print(std::ostream& os, char ofc) const 
{
  for (const auto& item : data) 
  {
    os << item << ofc;
  }
}

// Non-member function implementations
template <typename T>
std::ostream& operator<<(std::ostream& os, const Stack<T>&a)
{
  a.print(os); 
  return os; 
}

template <typename T>
bool operator==(const Stack<T>& a, const Stack<T>& b)
{
  return(a.data == b.data); 
}

template<typename T>
bool operator!=(const Stack<T>& a, const Stack<T>& b)
{
  return !(a == b);
}

template <typename T>
bool operator<=(const Stack<T>& a, const Stack<T>& b) 
{
  auto size_a = a.size();
  auto size_b = b.size();
  size_t min_size = std::min(size_a, size_b);

  for (size_t i = 0; i < min_size; ++i)
  {
    const T& elem_a = a.data[size_a - 1 - i];
    const T& elem_b = b.data[size_b - 1 - i];
    if (elem_a > elem_b)
    {
      return false;
    }
    else if (elem_a < elem_b)
    {
      return true;
    }
  }
  return size_a <= size_b;
}

} // namespace cop4530

#endif // STACK_HPP