#ifndef STACK_H
#define STACK_H

#include <iostream>
#include <vector>

using namespace std; 

namespace cop4530 {

template <typename T>
class Stack {
    private: 
        std::vector<T> data; 

    public: 
        Stack(); 
        ~Stack();
        Stack(const Stack<T>& a);
        Stack(Stack<T>&& a);

        Stack<T>& operator=(const Stack<T>& a);
        Stack<T>& operator=(Stack<T>&& a); 

        bool empty() const; 
        void clear(); 
        void push(const T& x); 
        void push(T&& x);
        void pop();
        T& top();
        const T& top() const; 
        int size() const; 
        void print(std::ostream& os, char ofc = ' ') const; 

        // Make the operator<< a friend function
        template <typename U>
        friend std::ostream& operator<<(std::ostream& os, const Stack<U>& a);

        // Make other operators friends to access private members
        template <typename U>
        friend bool operator==(const Stack<U>& a, const Stack<U>& b);
        
        template <typename U>
        friend bool operator!=(const Stack<U>& a, const Stack<U>& b);
        
        template <typename U>
        friend bool operator<=(const Stack<U>& a, const Stack<U>& b);
}; 

} // namespace cop4530

#include "stack.hpp"
#endif // STACK_H