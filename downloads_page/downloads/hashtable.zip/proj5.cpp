#include <iostream>
#include <string>
#include "hashtable.h"
#include "passserver.h"
using namespace std; 

void Menu(); 
void optionCalls(cop4530::PassServer &user, const char &input); 
int main()
{
  cout << "Welcome to the Eric's user database!" << endl;

  int size; 
  cout << "Enter preferred hash table capacity (integer): "; 
  cin >> size; 
  cop4530::PassServer user(size); 
  cout << "Hash table resized to the nearest prime: " << user.table_size() << endl; 
  char input; 
  do {
    Menu(); 
    cin >> input; 
    optionCalls(user, input);
  } while (input != 'x'); 
  return 0;
}
void Menu()
{
  cout << "\n\n";
  cout << "l - Load From File" << endl;
  cout << "a - Add User" << endl;
  cout << "r - Remove User" << endl;
  cout << "c - Change User Password" << endl;
  cout << "f - Find User" << endl;
  cout << "d - Dump HashTable" << endl;
  cout << "s - HashTable Size" << endl;
  cout << "w - Write to Password File" << endl;
  cout << "x - Exit program" << endl;
  cout << "\nEnter choice : ";
}


void optionCalls(cop4530::PassServer &user, const char &input)
{
  string username, password, oldPassword, newPassword, fileName;  
  pair <string, string> stringPair; 
  cin.ignore();
  switch(input)
  {
    case 'l' :
    cout << "Enter the file name to load with the whole file extension: "; 
    getline(cin,fileName); 
    if (user.load(fileName.c_str()))
    {
      cout << "The file loaded successfully." << endl; 
    }
    else
    cout << "There was en error in reading your file." << endl; 
    break; 

    case 'a' :
    cout << "Type in the username: "; 
    getline(cin, username); 
    cout << "Type in the password: "; 
    getline(cin, password); 

    

    stringPair = {username, password}; 

    if (user.addUser(stringPair))
    cout << "Username added successfully. " << endl; 

    break; 

    case 'r' : 
    user.dump(); 
    cout << "What user would you like to remove? ";
    getline(cin, username); 
    if (user.removeUser(username))
    {
      cout << "The user was removed successfully." << endl; 
    } 

    else 
    cout << "Error: could not find the username." << endl; 
    break; 

    case 'c' : 
    user.dump();  
    cout << "What user's password would you like to change? ";
    getline(cin, username); 
    cout << "Current password: "; 
    getline(cin, oldPassword);
    stringPair = {username, oldPassword}; 

    cout << "New password: ";  
    getline(cin, newPassword); 
    if (user.changePassword(stringPair, newPassword))
    {
      cout << "Password changed successfully." << endl; 
    }

    else 
    cout << "Error: password failed to change." << endl; 
    break; 

    case 'f' : 
    cout << "Which user would you like to search for? "; 
    getline(cin, username);
    if (user.find(username))
    {
      cout << "The username " << username << " is in the system." << endl; 
    } 

    else 
    cout << "The username " << username << " has not yet been added into the system." << endl;
    break;

    case 'd' : 
    user.dump();
    break;

    case 's' : 
    cout << "The size of the database is: " << user.size() << endl;  
    break; 

    case 'w' : 
    cout << "Enter the file name to write in to: ";
    getline(cin, fileName); 
    if (user.write_to_file(fileName.c_str()))
    {
      cout << "File has been successfully been written." << endl; 
    }
    else 
    cout << "Error writing into file." << endl; 
    break; 

    case 'x' : 
    cout << "Exiting program..." << endl; 
    break;

    default : 
    cout << "Invalid choice, please type in the correct input." << endl; 
  }
}