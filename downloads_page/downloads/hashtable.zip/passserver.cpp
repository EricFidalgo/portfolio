/* This file deals with the pair username and password which is similar in a way of the hashtable.hpp. A version of encrypt() was provided by my professor. */
#include "passserver.h"
#include <iostream>
#include <fstream>
#include <stdexcept>

#include <iostream>
#include <random>
#include <string>
#include <stdexcept>
#include <cstring>
#include <unistd.h> // For crypt


namespace cop4530 {

std::string PassServer::encrypt(const std::string &str)
{
	char salt[] = "$1$########"; // Fixed salt for MD5 hashing
	char *password = new char[100]; // Allocate memory for the encrypted string

	// Perform encryption
	strcpy(password, crypt(str.c_str(), salt));

	// Convert the result to std::string
	std::string encrypted(password);

	// Free allocated memory
	delete[] password;

	// Extract the hashed part (after the last '$')
	// Find the position of the last '$' in the string
	size_t pos = 0;
	for (size_t i = 0; i < encrypted.size(); ++i)
	{
		if (encrypted[i] == '$')
		{
			pos = i; // Update position each time we find a '$'
		}
	}
  
		return encrypted.substr(pos + 1); // Print after the last $
}

PassServer::PassServer(size_t size)
{
  users = cop4530::HashTable<std::string, std::string>(size);
}

PassServer::~PassServer()
{
  users.clear(); 
}

bool PassServer::load (const char *filename)
{
  std::ifstream file(filename);
  if (file.is_open() == false) 
  {
    std::cout << "Error: File could not be opened." << std::endl;
    return false;
  }

  std::string username, password; 
  while (file >> username >> password)
  {
    std::string passwrd_encrypt = encrypt(password); 
    users.insert(std::make_pair(username, passwrd_encrypt));
  }
  file.close(); 

  return true; 
}

bool PassServer::addUser(std::pair<std::string, std::string> & kv)
{

  if (users.contains(kv.first))
    {
        return false; // User already exists
    }

  std::string passwrd_encrypt = encrypt(kv.second);
  users.insert(std::make_pair(kv.first, passwrd_encrypt));
  return true;
}

bool PassServer::addUser(std::pair<std::string, std::string> && kv)
{
  if (users.contains(kv.first))
    {
        return false; // User already exists
    }

  std::string passwrd_encrypt = encrypt(std::move(kv.second));
  users.insert(std::make_pair(std::move(kv.first), passwrd_encrypt));
  return true; 
}

bool PassServer::removeUser(const std::string & k)
{
  users.remove(k);
  return true; 
}

bool PassServer::changePassword(const std::pair<std::string, std::string> &p, const std::string & newpassword)
{
  if (users.contains(p.first) == false)
    {
      return false;
    }

  std::string encrypted_current = encrypt(p.second);
  std::pair<std::string, std::string> current_pair = {p.first, encrypted_current};

  if (users.match(current_pair) == false)
    {
      return false; 
    }

  std::string encrypted_new = encrypt(newpassword);
  if (encrypted_new == encrypted_current)
    {
      return false; 
    }

  std::pair<std::string, std::string> new_pair = {p.first, encrypted_new};
  users.insert(new_pair); 
  return true; 
}

bool PassServer::find(const std::string & user) const
{
  return users.contains(user);
}

void PassServer::dump()
{
  users.dump();
}

size_t PassServer::size() const
{
  return users.size();
}

bool PassServer::write_to_file(const char *filename) const
{
  users.write_to_file(filename);
  return true; 
}

size_t PassServer::table_size() const 
{
  return users.table_size(); 
}
}